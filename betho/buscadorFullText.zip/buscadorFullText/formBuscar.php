<?php
// iniciamos session para no propagar por url variables que nos van a ayudar
// a mejorar la rapidez y la presentacion.
session_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>BUSCADOR FULLTEXT + PAGINADOR</title>
</head>

<body>
	<?php
	// Parametros a ser usados por el Paginador y el Buscador
	$cantidadRegistrosPorPagina	= 1;
    $cantidadEnlaces            = 5; // Cantidad de enlaces que tendra el paginador.
    $totalRegistros             = 0;
    
    // Vemos si viene por el paginador o por el form del buscador
    if (isset($_POST['buscar'])) { // Viene por el buscador
        $pagina                 = 0;
        $inicioLimit            = 0;
        $_SESSION['BUSCAR']     = $_POST['buscar'];
        // Configuro el paginador
        require_once 'BuscadorFullText.php';
        $objBuscador				= new BuscadorFullText($_POST['buscar'], 'buscador');
        // Agregamos los campos donde se buscara las palabras o criterios de busqueda
        $objBuscador->addCamposFullText('titulo, desarrollo');

        // Campos que se obtendran como resultado
        $objBuscador->addCamposResultado(array('idNoticia', 'titulo', 'desarrollo', 'categoria'));

        // Parametros que pueden variar en este caso debe coincidir el nombre del campo en el form html
        // con el nombre en la tabla MySQL
        if (isset($_POST['categoria']) && $_POST['categoria'] ) {
            $objBuscador->addParametrosVariables('categoria' , '=');
        }
        // añade a la consulta una condicion fija
        $objBuscador->addParametrosFijos("estado LIKE 'aprobada'");
        
        // Para limitar la cantidad de caracteres en la salida de algun campo
        $objBuscador->limitarLargo('titulo', 100);
        $objBuscador->limitarLargo('desarrollo', 250);
        // Capturamos la consulta que se debe realizar y agregamos el limit
        $consulta                = $objBuscador->getConsultaMysql();
        $_SESSION['CONSULTA']    = $consulta;

    } else { // Viene por el paginador
        $pagina					= isset($_GET['pagina'])? $_GET['pagina'] : 0;
        $inicioLimit			= $cantidadRegistrosPorPagina * $pagina;
        $consulta               = isset($_SESSION['CONSULTA'])?$_SESSION['CONSULTA'] : '';
        $_SESSION['BUSCAR']     = isset($_SESSION['BUSCAR'])? $_SESSION['BUSCAR'] : '';
    }

	// incluimos e instanciamos la clase buscadorFullText, pasando como parametros
    // el valor del campo de busqueda y la tabla a buscar.
	?>
    <div align="center">
	<form id="form1" name="form1" method="post" action="">
		<input type="text" name="buscar" id="buscar" value="<?php echo $_SESSION['BUSCAR']; ?>" />
			<select name="categoria" id="categoria">
		  		<option value="0">Todo el Sitio</option>
                <option value="Noticias">Noticias</option>
		  		<option value="Reportes">Reportes</option>
		  		<option value="Revisiones">Revisiones</option>
	    	</select>
	  	<input type="submit" name="enviar" id="enviar" value="Enviar" />
    </form>
    <?php
	echo 'Consulta Generada: <br />' .$consultaLimit      = sprintf($consulta, $inicioLimit, $cantidadRegistrosPorPagina);
    echo '</div><br /><br />';

    if ($consultaLimit) {
        // CONEXION MYSQL
        // Bueno ahora lo hacemos con la clasica mysql_connect.
        $conexion           = mysql_connect('localhost', 'root', '');
        mysql_select_db('buscadorfulltext', $conexion);
        $resultados         = mysql_query($consultaLimit, $conexion);
        $resultadosCantidad = mysql_fetch_row(mysql_query("SELECT FOUND_ROWS();", $conexion));
        $totalRegistros     = $resultadosCantidad[0];   // Se usara en el Paginador
        // Mostramos los resultados de la forma clasica
        echo '<table>';
        while($fila = mysql_fetch_array($resultados)) {
            echo '<tr >';
                echo '<td style="border:1px; border-style:solid;">' . $fila['idNoticia'] . '</td>';
                echo '<td style="border:1px; border-style:solid;">' . $fila['titulo'] . '</td>';
                echo '<td style="border:1px; border-style:solid;">' . $fila['desarrollo'] . '</td>';
                echo '<td style="border:1px; border-style:solid;">' . $fila['categoria'] . '</td>';
            echo '</tr>';
        }
        echo '</table>';
    } else { // Muestro Propiedades del Buscador
    ?>
     <div align="center">
  <center>
  <table border="0" cellpadding="0" cellspacing="0" width="450" id="AutoNumber1" height="312">
    <tr>
      <td height="17" colspan="2">Propiedades del Buscador FULLTEXT</td>
      </tr>
    <tr>
      <td width="11%" height="17"><b>Operador</b></td>
      <td width="89%" height="17">
      <p align="center"><b>Significado</b></td>
    </tr>
    <tr>
      <td width="11%" align="center" height="13"></td>
      <td width="89%" height="13"> </td>
    </tr>
    <tr>
      <td width="11%" align="center" height="36" style="border-bottom: 1px dotted #000000">&nbsp;</td>
      <td width="89%" height="36" align="justify" style="border-bottom: 1px dotted #000000">Por defecto no se especifica nada, las palabras son
      optativas pero tendran mayor importancia los registros con mas palabras
      coincidentes. </td>
    </tr>
    <tr>
      <td width="11%" align="center" height="23" style="border-bottom: 1px dotted #000000">+</td>
      <td width="89%" height="23" align="justify" style="border-bottom: 1px dotted #000000">Indica que la palabra debe estar presente en los&nbsp;
      registro buscados. </td>
    </tr>
    <tr>
      <td width="11%" align="center" height="23" style="border-bottom: 1px dotted #000000">-</td>
      <td width="89%" height="23" align="justify" style="border-bottom: 1px dotted #000000">Indica que la palabra no debe estar presente en los
      registros buscados.</td>
    </tr>
    <tr>
      <td width="11%" align="center" height="54" style="border-bottom: 1px dotted #000000">&lt;&gt;</td>
      <td width="89%" height="54" align="justify" style="border-bottom: 1px dotted #000000">Estos dos operadores se acostumbran a usar para cambiar la
      importancia de una palabra en la b&uacute;squeda. El signo &lt; disminuye la
      contribuci&oacute;n y el signo &gt;&nbsp; la aumenta. </td>
    </tr>
    <tr>
      <td width="11%" align="center" height="90" style="border-bottom: 1px dotted #000000">~</td>
      <td width="89%" height="90" align="justify" style="border-bottom: 1px dotted #000000">El tilde opera como negaci&oacute;n, causando una importancia negativa de la
      palabra en la b&uacute;squeda. Es &uacute;til para marcar las palabras de ruido. Una
      fila que contiene dicha palabra se le dara una importancia mas baja que
      otras, pero no se excluir&aacute; de los resultados, como si ocurrir&iacute;a si se
      usara el operador menos.</td>
    </tr>
    <tr>
      <td width="11%" align="center" height="36" style="border-bottom: 1px dotted #000000">&quot;</td>
      <td width="89%" height="36" align="justify" style="border-bottom: 1px dotted #000000">Las comillas dobles al principio y final de una frase,
      buscara s&oacute;lo registros que contienen la frase completa , tal como se
      tecle&oacute;.</td>
    </tr>
    </table>
  </center>
</div>

    <?php
    }
    // Comenzamos con el paginador.
    require_once 'Paginador.php';
    // Instanciamos la clase Paginador
    $paginador          = new Paginador();

    // Configuramos cuanto registros por pagina que debe ser igual a el limit de la consulta mysql
    $paginador->setCantidadRegistros($cantidadRegistrosPorPagina);
    $paginador->setCantidadEnlaces($cantidadEnlaces);
    
    // Y mandamos a paginar desde la pagina actual y le pasamos tambien el total
    // de registros de la consulta mysql.
    $datos              = $paginador->paginar($pagina, $totalRegistros);
    

    // Preguntamos si retorno algo, si retorno paginamos con los datos que nos da el
    // paginador que es un arreglo.
    if ($datos) {
        echo '<div align="center">';
        echo 'Pagina: ' . ($pagina + 1) . ' de ' . $paginador->getCantidadPaginas() . '<br />';
        echo 'Registros encontrados: ' . $totalRegistros . '<br />';
        foreach ($datos as $enlace) {
        ?>
            <a href="?pagina=<?php echo $enlace['numero']; ?>" title="<?php echo $enlace['title']; ?>" style="text-decoration:none;"><?php echo $enlace['vista']; ?></a>
        <?php
        }
        echo "</div>";
    }
    ?>
    <br />
</body>
</html>
